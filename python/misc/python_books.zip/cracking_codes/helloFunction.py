def hello(name):
    print('Hello, ' + name)
print('Start.')
hello('Alice')
print('Call the function again:')
hello('Bob')
print('Done.')