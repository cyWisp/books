def addNumbers(a, b):
    return a + b

print(addNumbers(2, 40))