CREATE INDEX vendors_zip_code_ix ON vendors (vendor_zip_code);
