Not all of the exercises have solutions that can easily 
be stored in a file. These folders only include the 
solutions that can easily be stored in a file.