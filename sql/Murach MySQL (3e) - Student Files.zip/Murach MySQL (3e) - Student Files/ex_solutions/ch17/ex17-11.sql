USE ap;

SELECT * FROM invoices;