GRANT UPDATE
ON ap.invoice_line_items
TO ray@localhost
WITH GRANT OPTION;